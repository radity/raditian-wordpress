<?php
return array(
	'api_key'              => '',
	'allow_usage_tracking' => 0,
	'debug_log_level'      => 'warning',
);
